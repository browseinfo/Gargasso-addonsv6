# -*- coding: utf-8 -*-
##############################################################################
#
#    Manufacturing Subcontracting Process
#    Copyright (C) 2004-2010 Browse Info Pvt Ltd (<http://www.browseinfo.com>).
#    $autor:
#   
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import time
import datetime
from report import report_sxw

class mo_merge_report(report_sxw.rml_parse):
    def __init__(self, cr, uid, name, context):
        super(mo_merge_report, self).__init__(cr, uid, name, context=context)
        self.localcontext.update({
             'time': time,
             'do_merge':self._do_merge,
             'do_data': self._do_data,
        })
        
    def _do_data(self,form):
        mo_ids = form.get('ids')
        mrp_obj = self.pool.get('mrp.production')
        res = []
        for mrp in mrp_obj.browse(self.cr,self.uid, mo_ids):
            res.append({
                        'name': mrp.name, 
                        'date': mrp.date_planned,
                        'product': mrp.product_id.name or '',
                        'code': mrp.product_id.default_code or '',
                        'qty':mrp.product_qty,
                        'uom': mrp.product_uom.name or '',
                        
                        })
        return res

    def _do_merge(self,form):
        mo_ids = form.get('ids')
        mrp_obj = self.pool.get('mrp.production')
        mrp_data = mrp_obj.browse(self.cr,self.uid, mo_ids,)[0]
        ids = []
        res = []
        for name in mrp_data.name.split('-'):
            new_name = name.strip()
            mrp_ids = mrp_obj.search(self.cr,self.uid, [('origin', 'ilike', new_name)])
            
        for mrp in mrp_obj.browse(self.cr,self.uid, mrp_ids):
            res.append({
                        'name': mrp.name, 
                        'date': mrp.date_planned,
                        'product': mrp.product_id,
                        'qty':mrp.product_qty,
                        'uom': mrp.product_uom.name or '',
                        'src':mrp.origin,
                        
                        })
        return res

report_sxw.report_sxw(
    'report.mo.merge.report',
    'mrp.production',
    'addons/merge_mo_report/report/merge_mo_report.rml',
    parser=mo_merge_report,
    header='external'
)
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
