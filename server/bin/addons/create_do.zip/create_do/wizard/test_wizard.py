# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from osv import osv, fields
from tools.translate import _

import netsvc

class stock_delivery_createlines(osv.osv_memory):
    _name = "stock.delivery.createlines"

    _columns = {
        'sale_order' : fields.char('Sale Order Number', size=32),
#        'sale_id': fields.many2one('sale.order', 'sale', required=True),
        'delivery_ids' : fields.many2many('stock.move', 'move_delivery_rel', 'move_id', 'mrp_id', 'Products to Deliver'),

    }

    _defaults = {

    }
    
    def crate_lines(self, cr, uid, ids, context={}):
        mrp_obj = self.pool.get('mrp.production')
        move_obj = self.pool.get('stock.move')
        sale_obj = self.pool.get('sale.order')
        sale_order = self.browse(cr, uid, ids, context=context)[0].sale_order
#        sale_name = sale_obj.browse(cr, uid, [sale_id.id])[0]
        mrp_ids = mrp_obj.search(cr, uid, [('origin', 'ilike', sale_order), ('state','=', 'done')])
        list_move = []
        if mrp_ids:
            for mrp_id in mrp_ids:
                mrp_move_id = mrp_obj.browse(cr, uid, mrp_id, context=context).move_created_ids2
                ids_mov = [mrp_move_id[0].id]
                for move in move_obj.browse(cr, uid, ids_mov, context=context):
                    if move.state == 'done':
                        list_move.append(move.id)
            self.write(cr, uid, ids, {'delivery_ids': [(6, 0, list_move)]},context=context)
        else:
            raise osv.except_osv(_('Warning !'),_('There is no finished products on this manufacturing order.'))
        return True

    def crate_do_lines(self, cr, uid, ids, context={}):
        picking_obj = self.pool.get('stock.picking')
        move_obj = self.pool.get('stock.move')
        mod_obj = self.pool.get('ir.model.data')
        do_ids = self.browse(cr, uid, ids, context=context)[0].delivery_ids
        input_location = mod_obj.get_object_reference(cr, uid, 'stock', 'stock_location_stock')
        output_location = mod_obj.get_object_reference(cr, uid, 'stock', 'stock_location_customers')
        if not do_ids:
            raise osv.except_osv(_('Warning !'),_('There is no move line for create delivery Order.'))
            return True
        else:
            pick_data = {
            'type': 'out',
            'state': 'draft',
            }
            picking_id = picking_obj.create(cr, uid, pick_data)
            for do_id in do_ids:
    #                
                for move in move_obj.browse(cr, uid, [do_id.id], context=context):
                    move_line = {
                            'name': move.name,
                            'picking_id': picking_id,
                            'product_id': move.product_id.id,
                            'date': move.date,
                            'date_expected': move.date_expected,
                            'product_qty': move.product_qty,
                            'product_uom': move.product_uom.id,
                            'product_uos_qty': (move.product_uos and move.product_uos_qty) or move.product_qty,
                            'product_uos': (move.product_uos and move.product_uos.id)\
                                or move.product_uom.id,
                            'product_packaging': move.product_packaging.id,
                            'location_id': move.location_id and move.location_id.id or False,
                            'location_dest_id': 9 or False,
                            #'sale_line_id': line.id,
                            'tracking_id': False,
                            'state': 'draft',
                            'note': move.note,
                            'company_id': move.company_id.id,
                            #'price_unit': line.product_id.standard_price or 0.0
                            }
                    move_id = move_obj.create(cr, uid, move_line)
        return {
                'name': _('Move     Moves'),
                'view_type': 'form',
                'view_mode': 'tree,form',
                'res_model': 'stock.move',
                'view_id': False,
                'type': 'ir.actions.act_window',
            }

stock_delivery_createlines()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
